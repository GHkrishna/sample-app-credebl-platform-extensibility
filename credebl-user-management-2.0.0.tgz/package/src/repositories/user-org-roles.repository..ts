import { Injectable, Logger } from '@nestjs/common';

import { InternalServerErrorException } from '@nestjs/common';
// eslint-disable-next-line camelcase
import { PrismaService, user_org_roles, Prisma } from '@credebl/prisma-service';

type UserOrgRolesWhereUniqueInput = Prisma.user_org_rolesWhereUniqueInput;

@Injectable()
export class UserOrgRolesRepository {
  private readonly logger: Logger
  constructor(
    private readonly prisma: PrismaService,
  ) {
    this.logger = new Logger('UserOrgRolesRepository')
  }

  /**
   *
   * @param createUserDto
   * @returns user details
   */
  // eslint-disable-next-line camelcase
  async createUserOrgRole(userId: string, roleId: string, orgId?: string, idpRoleId?: string): Promise<user_org_roles> {
    try {
      const data: {
        orgRole: { connect: { id: string } };
        user: { connect: { id: string } };
        organisation?: { connect: { id: string } };
        idpRoleId?: string;
      } = {
        orgRole: { connect: { id: roleId } },
        user: { connect: { id: userId } }
      };

      if (orgId) {
        data.organisation = { connect: { id: orgId } };
      }

      if (idpRoleId) {
        data.idpRoleId = idpRoleId;
      }

      const saveResponse = await this.prisma.user_org_roles.create({
        data
      });

      return saveResponse;
    } catch (error) {
      this.logger.error(`UserOrgRolesRepository:: createUserOrgRole: ${error}`);
      throw new InternalServerErrorException('User Org Role not created');
    }
  }

  /**
   *
   * @param
   * @returns organizations details
   */
  // eslint-disable-next-line camelcase
  async getUserOrgData(queryOptions: object): Promise<user_org_roles[]> {
    try {
      return this.prisma.user_org_roles.findMany({
        where: {
          ...queryOptions
        },
        include: {
          organisation: {
            include: {
              // eslint-disable-next-line camelcase
              org_agents: true,
              orgInvitations: true
            }
          },
          orgRole: true
        }
      });
    } catch (error) {
      this.logger.error(`error: ${JSON.stringify(error)}`);
      throw new InternalServerErrorException(error);
    }
  }

  async findAndUpdate(queryOptions: UserOrgRolesWhereUniqueInput, updateData: object): Promise<object> {
    try {
      return this.prisma.user_org_roles.update({
        where: queryOptions,
        data: updateData
      });
    } catch (error) {
      this.logger.error(`error in findAndUpdate: ${JSON.stringify(error)}`);
      throw new InternalServerErrorException(error);
    }
  }

  async deleteMany(queryOptions: object): Promise<object> {
    try {
      return this.prisma.user_org_roles.deleteMany({
        where: { ...queryOptions }
      });
    } catch (error) {
      this.logger.error(`error in deleteMany: ${JSON.stringify(error)}`);
      throw new InternalServerErrorException(error);
    }
  }
}
